<div class="sidebar-wrapper">
            <div class="logo">
                <a href="index.php" class="simple-text">
                    Unique Restaurant
                </a>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="food_list.php">
                        <i class="pe-7s-graph"></i>
                        <p>List Makanan</p>
                    </a>
                </li>
                <li>
                    <a href="food_add.php">
                        <i class="pe-7s-note"></i>
                        <p>Tambah Makanan</p>
                    </a>
                </li>
				
                <li>
                    <a href="orders.php">
                        <i class="pe-7s-note2"></i>
                        <p>Pesanan</p>
                    </a>
                </li>
				<li>
                    <a href="reservations.php">
                        <i class="pe-7s-note2"></i>
                        <p>Pemesanan Meja</p>
                    </a>
                </li>
				<!--<li>
                    <a href="#">
                        <i class="pe-7s-news-paper"></i>
                        <p>Gallery</p>
                    </a>
                </li>-->
                
            </ul>
    	</div>
    </div>