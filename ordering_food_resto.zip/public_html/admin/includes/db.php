<?php 
	
	$db = new mysqli("localhost", "id13890654_db_uniqueorderingfood", "foodOrdering123!@#", "id13890654_mfors_1_");
	
	if($db->connect_error) {
		
		echo "PLEASE BEAR WITH US AS WE ARE CURRENTLY WORKING ON OUR SITE!!!! PLEASE COME BACK LATER";
		
	}
	
?>